<?php

namespace IPP\Student\Frame;

class TemporaryFrame extends Frame {
}
