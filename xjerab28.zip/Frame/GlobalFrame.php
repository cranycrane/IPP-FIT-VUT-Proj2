<?php

namespace IPP\Student\Frame;

class GlobalFrame extends Frame {
}
