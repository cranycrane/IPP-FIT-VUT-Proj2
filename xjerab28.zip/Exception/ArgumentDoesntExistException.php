<?php

namespace IPP\Student\Exception;

use Exception;

class ArgumentDoesntExistException extends Exception {
    
}