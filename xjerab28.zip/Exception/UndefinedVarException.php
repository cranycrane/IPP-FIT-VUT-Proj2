<?php

namespace IPP\Student\Exception;

use Exception;

class UndefinedVarException extends Exception {
    
}